/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Pathfinder
 *
 * (c) 2016-2019 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/Pathfinder.js';
